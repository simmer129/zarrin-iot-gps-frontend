import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'ngx-tracking-gps',
  templateUrl: './tracking-gps.component.html',
  styleUrls: ['./tracking-gps.component.scss']
})
export class TrackingGpsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
