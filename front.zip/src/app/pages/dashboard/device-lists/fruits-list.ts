export const fruits: string[] = [
  'GpsYek',
  'GpsDo',
  'GpsSE',
  'GpsChahar',
  'GpsPanj',
  'Gpsshesh',
  'GpsHaft',
  'GpsHash',
  'GpsNoh',
  'GpsDah',
  'GpsYazdah',
];
export const devises: {name : string, serial : string}[]=[
  {name: 'GpsAval', serial: '235s4qw123'},
  {name: 'GpsDovom', serial: '925s4aw173'},
  {name: 'GpsSevom', serial: '435s4sc163'},
  {name: 'GpsChahrom', serial: '145re2e5'},
  {name: 'GpsPanjom', serial: '185re2e5'},
  {name: 'GpsHheshom', serial: '175re2e5'},
  {name: 'GpsHaftom', serial: '115re2e5'}
];